<?php
if(!isset($wpdb))
{
include_once('../../../wp-config.php');
mysql_select_db(DB_NAME);
}

function fc_my_dataminer_shortcode_handler($atts,$content='profile') {
   extract( shortcode_atts( array(
      'action' => 'profile'
      ), $atts ) );
   $strtrimmed = $content; 

   $Query = sprintf("select * from fc_content where id = 1");
	$result = mysql_query($Query) or die("A MySQL error has occurred.<br />Your Query: " . $Query . "<br /> Error: (" . mysql_errno() . ") " . mysql_error());
    $row = mysql_fetch_assoc( $result );
    $thisfield = '<div id="fbdm_' . $action . '" class="' . $action . '">' . $row[$action] . '</div>';
return $thisfield;
}
?>