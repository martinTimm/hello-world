<?php
if(!isset($wpdb))
{
include_once('../../../wp-config.php');
mysql_select_db(DB_NAME);
}

function fc_update_list($field,$content) {
$nowdate = date('Y-m-d H:i:s');
$fc_content = urldecode($content);
//$fc_content = trim($fc_content); 
//$fc_content = addslashes($fc_content);
//$fc_content = mysql_real_escape_string($fc_content);

$Query = sprintf("update fc_content set $field = \"$fc_content\",timestamp = \" $nowdate \" ");

echo $Query; 
$result = mysql_query($Query);// or die("A MySQL error has occurred.<br />Your Query: " . $Query . "<br /> Error: (" . mysql_errno() . ") " . mysql_error());
}

fc_update_list($_POST['field'],$_POST['content']);
?>