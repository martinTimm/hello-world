<?php
if(!isset($wpdb))
{
include_once('../../../wp-config.php');
mysql_select_db(DB_NAME);
}

$app_id = '';

function fc_starttable() {
	$Query = sprintf("CREATE TABLE IF NOT EXISTS `fc_content` (
  `friends` mediumtext NOT NULL,
  `timeline` mediumtext NOT NULL,
  `messages` mediumtext NOT NULL,
  `albums` mediumtext NOT NULL,
  `photos` mediumtext NOT NULL,
  `profilephoto` text NOT NULL,
  `id` int(11) NOT NULL,
  `profile` mediumtext NOT NULL,
  `posts` mediumtext NOT NULL,
  `likes` mediumtext NOT NULL,
  `videos` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;");
$result = mysql_query($Query) or die("A MySQL error has occurred.<br />Your Query: " . $Query . "<br /> Error: (" . mysql_errno() . ") " . mysql_error());
}

register_activation_hook(__FILE__, 'fc_starttable');

function fc_setuptable() {
	$Query = sprintf("INSERT INTO `fc_content` (`friends`, `timeline`, `messages`, `albums`, `photos`, `profilephoto`, `id`, `profile`, `posts`, `likes`, `videos`) VALUES('test', 'test', 'test', 'test', 'test', 'test', 1, 'test', 'test', 'test', 'test');");

	$result = mysql_query($Query) or die("A MySQL error has occurred.<br />Your Query: " . $Query . "<br /> Error: (" . mysql_errno() . ") " . mysql_error());
}
function fc_setthisappid() {
	$Query = sprintf("select app_id from fc_content");
	$result = mysql_query($Query) or die("A MySQL error has occurred.<br />Your Query: " . $Query . "<br /> Error: (" . mysql_errno() . ") " . mysql_error());
    while($row = mysql_fetch_assoc($result)){
    	global $app_id;
    	$app_id = $row['app_id'];
    }
}

function fc_checkappid() {
	$Query = sprintf("select app_id from fc_content");

	$result = mysql_query($Query) or die("A MySQL error has occurred.<br />Your Query: " . $Query . "<br /> Error: (" . mysql_errno() . ") " . mysql_error());
    while($row = mysql_fetch_assoc($result)){
    	$app_id = $row['app_id'];
    	$idLen = strlen($app_id);
    		if(!$idLen){
    		fc_setappid();
    	}
    		else {
    		fc_showpage();
    	}
    }
}

function fc_setappid() {
echo "You need an app id from facebook to use this plugin <a href='' target='top'>read this manual</a> if you don't know how.<form method='post' action='fb_miner.php'>
<input type='text' name='myid' id='myid'>
<input type='button' class='button button-primary' value='set app_id' onClick='fc_sendit()'><a href=''>?</a>
</form>";
exit();
}

function fc_showpage() {
echo "<div align='center'> 
	<Div id='log'></div>
	<h1>Facebook Dataminer</h1>
	<div id='status'>
	<H4> Click here to log in with Facebook:</H4> 
	<img src='" .plugins_url('img/LoginWithFacebook.png',__FILE__). "' style='cursor:pointer;' onclick='fc_Login()'/>
	</div>
	 <div id='foto'></div>
	 <div id='buttons' style='visibility:hidden'>
 		<input type='button' id='fbdm_getFriends' class='button action' value='friends' onclick='fc_getFriends()'>
 	 	<input type='button' id='fbdm_getTimeLine' class='button action' value='startpage' onclick='fc_getTimeLine()'>
  	 	<input type='button' id='fbdm_getMessages' class='button action' value='messages' onclick='fc_getMessages()'>
  	 	<input type='button' id='fbdm_getAlbums' class='button action' value='albums' onclick='fc_getAlbums()'> 
	 	<input type='button' id='fbdm_getPhotos' class='button action' value='photo&#146;s' onclick='fc_getPhotos()'>
	 	<input type='button' id='fbdm_getPhoto' class='button action' value='profile photo' onclick='fc_getPhoto()'> 
	 	<input type='button' id='fbdm_getUserInfo' class='button action' value='profile ' onclick='fc_getUserInfo()'> 
     	<input type='button' id='fbdm_getPosts' class='button action' value='last posts' onclick='fc_getPosts()'> 
 	 	<input type='button' id='fbdm_getLikes' class='button action' value='site-likes' onclick='fc_getLikes()'>
 	 	<input type='button' id='fbdm_getVideos' class='button action' value='video&#146;s' onclick='fc_getVideos()'> 
 	 	<input type='button' value='help' class='button button-primary' onclick='fc_updateall()'>
 	 </div>
 	<br>
		<br/>
		<div id='shortcode'></div>
		<div id='message' class='message'></div>
	</div>";	
}

function fc_my_dataminer_shortcode_handler($atts,$content='profile') {
   extract( shortcode_atts( array(
      'action' => 'profile'
      ), $atts ) );
   $strtrimmed = $content; 

   $Query = sprintf("select * from fc_content where id = 1");
	$result = mysql_query($Query) or die("A MySQL error has occurred.<br />Your Query: " . $Query . "<br /> Error: (" . mysql_errno() . ") " . mysql_error());
    $row = mysql_fetch_assoc( $result );
    $thisfield = '<div id="fbdm_' . $action . '" class="' . $action . '">' . $row[$action] . '</div>';
return $thisfield;
}
?>