 var user = '';
 var dezecontent = '';
 var iDiv = '';
 
//alert(php_data.app_id);
 
function fc_Login()
    {
        FB.login(function(response) {
           if (response.authResponse) 
           {
            fc_getUserInfo();
            } else 
            {
             alert('You cancelled login or did not fully authorize.');
            }
         },{scope: 'email,user_photos,user_videos,user_likes,user_work_history,read_stream,read_mailbox,read_insights'});
    }    
function fc_logout() {
    	FB.logout(function(response) {
  		alert("you're logged out of facebook");
  		document.location.reload();
	});
}


function creatediv(naam) {
		document.getElementById('message').innerHTML = '';
  		iDiv = document.createElement('div');
		iDiv.id = naam;
		iDiv.className = naam;
		document.getElementById('message').appendChild(iDiv);
}

fc_getMessages = function() {
  		creatediv('messages');
  		setfbdmclass('fbdm_getMessages');
  		document.getElementById("shortcode").innerHTML = fc_getshortcodes('messages');
	FB.api('/platform/posts', { limit: 20 }, function(response) {
		post = response.data;
  for (var i=0, l=post.length; i<l; i++) {
    if (post[i].message) {
      iDiv.innerHTML += "<br><br> " + post[i].from.name + " said: " + post[i].message;
    } else if (post[i].attachment && post[i].attachment.name) {
    }
  var content = iDiv.innerHTML;
  fc_updateTable('messages',content);
  }
 });
};
  
function fc_getPhotos(){
  		creatediv('photos');
  		setfbdmclass('fbdm_getPhotos');
  		document.getElementById('shortcode').innerHTML = fc_getshortcodes('photos') 
  		var content = "<ul id='fbdm_photos-grid' class='fbdm_photos-grid'>";
        FB.api({
    		method: "fql.query",
    		query: "SELECT src, src_big, src_height, src_width, src_small, src_small_height, src_small_width FROM photo WHERE pid IN (SELECT pid FROM photo WHERE aid IN (SELECT aid FROM album WHERE owner='" + user + "' AND type!='profile'))"
}, function(rows){
					for (var i=0, l=rows.length; i<l; i++) {
                	content += "<li><a href='" + rows[i].src_big + "' target='top'><img src='" + rows[i].src + "'></a></li>";
   				}
   				content += "</ul>";
   				iDiv.innerHTML = content;
   				fc_updateTable('photos',content);
		});
    }    
function fc_getLikes(){
  		creatediv('likes');
  		setfbdmclass('fbdm_getLikes');
  		var content = "<ul id='fbdm_likes-grid' class='fbdm_likes-grid'>";
       // FB.api('/me', function(response) {
            var query  =  FB.Data.query("SELECT url from url_like where user_id = me()");
            document.getElementById('shortcode').innerHTML = fc_getshortcodes('likes');
           // iDiv.innerHTML = '';
            query.wait(function(rows) {
            	for (var i=0, l=rows.length; i<l; i++) {
                content += "<li><a href='" + rows[i].url + "' target='top'>" + rows[i].url + "</a></li>";
   				}
   			iDiv.innerHTML = content;
   			fc_updateTable('sitelikes',content);
            });
       // });
    }

  function fc_getUserInfo() {
  		creatediv('profile');
  		setfbdmclass('fbdm_getUserInfo');
        FB.api('/me', function(response) {
 		user = response.id;
 		document.getElementById('shortcode').innerHTML = fc_getshortcodes('profile');
      	var str = "<ul id='fbdm_profile-grid' class='fbdm_profile-grid'>";
      	  	str +="<li>name : "+response.name+"</li>";
          	str +="<li>facebook: <a href='"+ response.link + "' target='top'>" + response.link + "</a></li>";
          	str +="<li>Username: "+response.username+"</li>";
          	if(response.email.length)
          	str +="<li>E-mail: "+response.email+"</li>";
          	if(response.education[0].school.name.length)
          	str +="<li>school: "+response.education[0].school.name + "</li>";
          	if(response.work[0].employer.name.length)
          	str +="<li>work: "+response.work[0].employer.name + "</li>";
          	str +="</ul>";
          	iDiv.innerHTML=str;
          fc_updateTable('profile',str);
    	});
    }  
	fc_getAlbums = function() {
	creatediv('albums');
	setfbdmclass('fbdm_getAlbums');
  	FB.api('/me/albums', function(resp) {
    	document.getElementById('shortcode').innerHTML = fc_getshortcodes('albums');
    	if(!resp.data.length){
            	iDiv.innerHTML = "you haven't published any albums on Facebook.";
            	document.getElementById("shortcode").innerHTML = '';
         }
    	var content = "<ul>";
    	for (var i=0, l=resp.data.length; i<l; i++) {
      	var album = resp.data[i];
        //li = document.createElement('li'),
        //a = document.createElement('a');
      	//a.innerHTML = album.name;
      	//a.href = album.link; 
      	//li.appendChild(a);
      	//mydiv.appendChild(ul);
      	content += '<li><a href="' + album.link + '" target="top">' + album.name + '</a></li>';
    }
    iDiv.innerHTML += content + '</ul>';
   	fc_updateTable('albums',content);
  });
}; 
    function fc_getTimeLine() {
    	var dezeLink = '';
    	document.getElementById('shortcode').innerHTML = fc_getshortcodes('timeline');
    	creatediv('timeline');
    	setfbdmclass('fbdm_getTimeLine');
        FB.api('/me/home?limit=30', function(response) {
         var dezecontent = "<ul id='fbdm_timeline-grid' class='fbdm_timeline-grid'>";
         if(!response.data.length){
            	iDiv.innerHTML = "you're page seems to be empty..";
            	document.getElementById("shortcode").innerHTML = '';
           }
         for (var i=0, l=response.data.length; i<l; i++)   {
        	if (response.data[i].link === undefined){
        	dezeLink = '';
        	closelink = '';
        	}
        	else {
        	dezeLink = '<a href="' + response.data[i].link + '" target="top">';
        	closelink = '</a>';
        	}
        	
        	if (response.data[i].picture === undefined && response.data[i].message === undefined)
        	dezecontent += "";
        	else if(response.data[i].picture === undefined)
    		dezecontent += "<li>" + response.data[i].from.name + " says: " + response.data[i].message + "</li>";
        	else if(response.data[i].message === undefined)
        	dezecontent += "<li>" + response.data[i].from.name + "<br>" + dezeLink + "<img src='" + response.data[i].picture + "'>" + closelink + "</li>";
        	else if(response.data[i].description === undefined)
        	dezecontent += "<li>" + response.data[i].from.name + " says: "  + response.data[i].message + "<br>" + dezeLink + "<img src='" + response.data[i].picture + "'>" + closelink + "</li>";
        	else
        	dezecontent += "<li>"  + response.data[i].from.name + " says: " + response.data[i].message + " " + response.data[i].description + "<br>" + dezeLink + "<img src='" + response.data[i].picture + "'>" + closelink + "</li>";
        	if(l-i==1) {
        		dezecontent += "</ul>";
        		iDiv.innerHTML = dezecontent;
        		fc_updateTable('timeline',dezecontent);
        		}
        	}
    	});
    }
	function fc_getVideos() {
     	document.getElementById("shortcode").innerHTML = fc_getshortcodes('videos');
     	creatediv('videos');
     	setfbdmclass('fbdm_getVideos');
        FB.api('/me/feed', function(response) {
        var query  = FB.Data.query("SELECT embed_html FROM video WHERE owner = me()", response.id);
            query.wait(function(rows) {
            	if(!rows.length){
            	iDiv.innerHTML = "you've published no video's on facebook";
            	document.getElementById("shortcode").innerHTML = '';
            	}
            	for (var i=0, l=rows.length; i<l; i++) {
            	//var dit = $.parseJSON(response);
        		iDiv.innerHTML += rows[i].embed_html + "</a><br>";
   				}
   			var content = iDiv.innerHTML;
        	fc_updateTable('videos',content);
            });
        });
    }
     function fc_getPosts() {
     	creatediv('messages');
     	setfbdmclass('fbdm_getPosts');
     	document.getElementById("shortcode").innerHTML = fc_getshortcodes('posts');
     	var content = "<ul id='fbdm_posts-grid' class='fbdm_posts-grid'>";
        //FB.api('/me/feed', function(response) {
        var query  = FB.Data.query("SELECT actor_id, message, attachment,  comment_info, feed_targeting, like_info, share_info, type, permalink, type FROM stream WHERE source_id = me()");
            query.wait(function(rows) {
            	for (var i=0, l=rows.length; i<l; i++) {
            	content += "<li>";
            	if(rows[i].message !== undefined && rows[i].message.length)
            	content += rows[i].message;
        		if(rows[i].attachment.name !== undefined && rows[i].attachment.name.length)
        		content += rows[i].attachment.name; 
   				if(rows[i].attachment.description !== undefined && rows[i].attachment.description.length)
   				content += rows[i].attachment.description;
   				if(rows[i].attachment.media !== undefined && rows[i].attachment.media[0].src.length) 
   				content += "<img src='" + rows[i].attachment.media[0].src + "'>";
   				if(rows[i].attachment.href !== undefined)
   				content += "<br><a href='" + rows[i].attachment.href + "' target='top'> read more</a>";
   				content += "</li>";
   				}
   			content += "</ul>";
   			iDiv.innerHTML = content;
   			fc_updateTable('posts',content);
            });
       // });
    }

function fc_getFriends(){
     	creatediv('friends');
        FB.api('/me/friends', function(response) {
        	setfbdmclass('fbdm_getFriends');
            var query  =  FB.Data.query("SELECT name, pic, pic_square, profile_url FROM user WHERE uid IN (SELECT uid2 FROM friend WHERE uid1 = me())", response.id);
            document.getElementById('shortcode').innerHTML = fc_getshortcodes('friends');
            query.wait(function(rows) {     
        		if(rows.length == 0)
            	iDiv.innerHTML = "you\'ve got no friends on FB..";
            	else
            	var content = "<ul id='fbdm_friends-grid' class='fbdm_friends-grid'>";
            	for (var i=0, l=rows.length; i<l; i++) {
            	//var dit = $.parseJSON(response);
                var numb = i + 1;
        		content += "<li><a href='" + rows[i].profile_url +"' target='top'><img src='" + rows[i].pic_square + "'><br>" +  rows[i].name + "</a></li>";
      				}
   				var content = content + '</ul>';
   				iDiv.innerHTML = content;
   				fc_updateTable('friends',content);
            });
        });
    }      
    function fc_getPhoto(){
      creatediv('photo');
      setfbdmclass('fbdm_getPhoto');
      document.getElementById('shortcode').innerHTML = fc_getshortcodes('photo');
      FB.api('/me/picture?type=normal', function(response) {
          var str="<img src='"+response.data.url+"'/>";
          iDiv.innerHTML= str;
          fc_updateTable('photo',str);
    });
}
function fc_updateall() {
//why doesn't this get hidden....
document.getElementById("message").style.visibility='hidden';
		fc_getFriends();
		fc_getTimeLine();
		fc_getMessages();
		fc_getAlbums();
		fc_getPhotos();
		fc_getPhoto();
		fc_getUserInfo(); 
		fc_getPosts();
		fc_getLikes();
		fc_getVideos();
// the code below doesn't work because messages tkans too long to proces
document.getElementById("message").innnerHTML='Im ready with the update!';
document.getElementById("message").style.visibility='visible';
}

function fc_getshortcodes(field) {
var shortcode;
var message;
switch(field)
	{
	case 'friends':
  	shortcode = '[fb_dataminer section="friends"/]';
  	break;
	case 'timeline':
  	shortcode = '[fb_dataminer section="timeline"/]';
  	break;
  	case 'messages':
  	shortcode = '[fb_dataminer section="messages"/]';
  	break;
  	case 'albums':
  	shortcode = '[fb_dataminer section="albums"/]';
  	break;
  	case 'photos':
  	shortcode = '[fb_dataminer section="photos"/]';
  	break;
	case 'photo':
  	shortcode = '[fb_dataminer section="photo"/]';
  	break;
	case 'profile':
  	shortcode = '[fb_dataminer section="profile"/]';
  	break;
	case 'posts':
  	shortcode = '[fb_dataminer section="posts"/]';
	break;
	case 'likes':
  	shortcode = '[fb_dataminer section="likes"/]';
  	break;
  	case 'videos':
  	shortcode = '[fb_dataminer section="videos"/]';
  	break;
	default:
	shortcode = '[fb_dataminer section="userinfo"/]';
	}
message = "<p>Copy and paste this shortcode: " + shortcode + "</p>";

return message;
}

window.fbAsyncInit = function() {
var logDiv = document.getElementById('log');
	if ((typeof(logDiv) != 'undefined' && logDiv != null)) {
    	FB.init({
      	appId      : fbdm_app_id, // Set YOUR APP ID
      	status     : true, // check login status
      	cookie     : true, // enable cookies to allow the server to access the session
      	xfbml      : true,  // parse XFBML
      	oauth		 : true
    	});
 
    	FB.Event.subscribe('auth.authResponseChange', function(response) 
    	{
     	if (response.status === 'connected') 
    		{
        	logDiv.innerHTML =  'You\'re connected to Facebook <br><a href=\'#\' onClick=\'fc_logout()\'>fb log out</a> | <a href=\'#\' onClick=\'\'>edit app_id</a> | <a href=\'#\' onClick=\'plugin-editor.php?file=fb-dataminer/css%2Ffb-dataminer.css&plugin=fb-dataminer%2Ffb_miner.php\'>style the datamaminer content</a>';
    		document.getElementById('status').innerHTML='';
    		document.getElementById('buttons').style.visibility='visible';
    		fc_getUserInfo()
    		}    
    	else if (response.status === 'not_authorized') 
    		{
        	logDiv.innerHTML =  'Connection failed';
    		} 
    	else 
    		{
        logDiv.innerHTML =  'You\'re logged out. <a href=\'index.php\'>click here to log in.</a>';
    		}
    	}); 
 	 }
};

function fc_sendit() {
	dezeId = document.getElementById('myid').value;
	fc_updateTable('app_id',dezeId);
}

function setfbdmclass(idname) {
document.getElementById('fbdm_getFriends').setAttribute("class", "button action");
document.getElementById('fbdm_getTimeLine').setAttribute("class", "button action");
document.getElementById('fbdm_getMessages').setAttribute("class", "button action");
document.getElementById('fbdm_getAlbums').setAttribute("class", "button action");
document.getElementById('fbdm_getPhotos').setAttribute("class", "button action");
document.getElementById('fbdm_getPhoto').setAttribute("class", "button action");
document.getElementById('fbdm_getUserInfo').setAttribute("class", "button action");
document.getElementById('fbdm_getPosts').setAttribute("class", "button action");
document.getElementById('fbdm_getLikes').setAttribute("class", "button action");
document.getElementById('fbdm_getVideos').setAttribute("class", "button action");
document.getElementById(idname).setAttribute("class", "button button-primary");
}

function fc_updateTable(field,content) {
  var dezeData= new Object();
      dezeData.field = field;
      dezeData.content = content;
      $.ajax({
              type: "POST",
              dataType: "array",
              url: fbdm_fc_pad + "/save.php",
              data: dezeData,
              success: function(msg) {
        }
   });
}