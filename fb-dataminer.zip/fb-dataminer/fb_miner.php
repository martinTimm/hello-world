<?php
/* Plugin Name: facebook dataminer
Plugin URI: http://loodvrij.nl/fbminer
Description: Use dataminer to fill your WP pages with your facebook content and SEO optimize your webpresence. Facebook dataminer is the easiest way to get data from facebook into your WP site.
Version: 1.0 
Author: Martin Timmers
Author URI: http://loodvrij.nl
License: GPLv2 or later
*/
/* 
Copyright 2015  martin timmers (email : martin@loodvrij.nl)
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/

if (is_admin())
{
require_once('qry.php');  
fc_setthisappid();
echo "<script>var fbdm_fc_pad ='" . plugins_url('', __FILE__) . "'; var fbdm_app_id =" . $app_id . ";</script>";
}
else {
require_once('frontend.php'); 
}

add_action('wp_enqueue_scripts', 'reg_scripts');  

function reg_scripts() {  
  wp_deregister_script( 'jquery' );
  wp_register_style('fc_dataminer_css', plugins_url('css/fb-dataminer.css', __FILE__),99);
  wp_enqueue_style('fc_dataminer_css');
  wp_register_script('goog', 'http://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.min.js');
  wp_enqueue_script('goog');
  if (is_admin())
	{
  	wp_register_script('facebookAll', '//connect.facebook.net/en_US/all.js');
  	wp_enqueue_script('facebookAll');
    wp_register_script('fc_dataminer', plugins_url('js/fc.js', __FILE__));
  	wp_enqueue_script('fc_dataminer');
  	//var id = fc_setthisappid();
  	//wp_localize_script('fc_dataminer', 'fbdm_app', id);
  	}
}
reg_scripts();
/**  */
add_action( 'admin_menu', 'fc_mypluginmenu' );

/**  */
function fc_mypluginmenu() {
	add_menu_page( 'Facebook Dataminer plugin', 'Facebook Dataminer', 'manage_options', 'fb_dataminer', 'fc_mypluginoptions' );
   // add_submenu_page('edit.php?post_type=wiki', 'Options', 'Options', 'manage_options', 'wiki-options', array(&$this, 'options_page') );
}

/** */
function fc_mypluginoptions() {
	if ( !current_user_can( 'manage_options' ) )  {
		wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
	}
	fc_checkappid();
}

/** */
add_shortcode("fbdataminer", "fc_my_dataminer_shortcode_handler");
?>